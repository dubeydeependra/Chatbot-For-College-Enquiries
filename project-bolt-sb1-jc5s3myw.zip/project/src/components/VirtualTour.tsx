import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, MapPin, X } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface TourLocation {
  id: string;
  name: string;
  description: string;
  image_url: string;
  order: number;
}

interface VirtualTourProps {
  onClose: () => void;
}

export function VirtualTour({ onClose }: VirtualTourProps) {
  const [locations, setLocations] = useState<TourLocation[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadLocations();
  }, []);

  const loadLocations = async () => {
    const { data } = await supabase
      .from('tour_locations')
      .select('*')
      .order('order', { ascending: true });

    if (data) {
      setLocations(data);
      setIsLoading(false);
    }
  };

  const goToPrevious = () => {
    setCurrentIndex((prev) => (prev === 0 ? locations.length - 1 : prev - 1));
  };

  const goToNext = () => {
    setCurrentIndex((prev) => (prev === locations.length - 1 ? 0 : prev + 1));
  };

  if (isLoading) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-2xl p-8 max-w-2xl w-full mx-4">
          <p className="text-center text-gray-600">Loading tour locations...</p>
        </div>
      </div>
    );
  }

  const currentLocation = locations[currentIndex];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        <div className="flex justify-between items-center p-6 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-gray-800">Virtual Campus Tour</h2>
          <button
            onClick={onClose}
            className="p-1 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-6 h-6 text-gray-600" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto">
          <div className="relative">
            <img
              src={currentLocation.image_url}
              alt={currentLocation.name}
              className="w-full h-96 object-cover"
            />
            <button
              onClick={goToPrevious}
              className="absolute left-4 top-1/2 -translate-y-1/2 bg-white rounded-full p-2 hover:bg-gray-100 transition-colors shadow-lg"
            >
              <ChevronLeft className="w-6 h-6 text-gray-800" />
            </button>
            <button
              onClick={goToNext}
              className="absolute right-4 top-1/2 -translate-y-1/2 bg-white rounded-full p-2 hover:bg-gray-100 transition-colors shadow-lg"
            >
              <ChevronRight className="w-6 h-6 text-gray-800" />
            </button>

            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-black bg-opacity-60 text-white px-4 py-2 rounded-full text-sm font-medium">
              {currentIndex + 1} / {locations.length}
            </div>
          </div>

          <div className="p-6">
            <div className="flex items-start gap-3 mb-4">
              <MapPin className="w-6 h-6 text-blue-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="text-2xl font-bold text-gray-800 mb-2">
                  {currentLocation.name}
                </h3>
                <p className="text-gray-700 leading-relaxed">
                  {currentLocation.description}
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-200 p-6 bg-gray-50">
          <div className="flex gap-3 justify-center flex-wrap">
            {locations.map((location, index) => (
              <button
                key={location.id}
                onClick={() => setCurrentIndex(index)}
                className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
                  currentIndex === index
                    ? 'bg-blue-600 text-white'
                    : 'bg-white text-gray-700 border border-gray-300 hover:border-blue-600'
                }`}
              >
                {index + 1}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
