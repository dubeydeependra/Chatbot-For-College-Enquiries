import { useEffect, useRef } from 'react';
import { GraduationCap, Loader2 } from 'lucide-react';
import { useChatbot } from '../hooks/useChatbot';
import { ChatMessage } from './ChatMessage';
import { ChatInput } from './ChatInput';
import { VirtualTour } from './VirtualTour';
import { TourBookingModal } from './TourBookingModal';

export function Chatbot() {
  const {
    messages,
    sendMessage,
    isLoading,
    showVirtualTour,
    setShowVirtualTour,
    showTourBooking,
    setShowTourBooking,
    sessionId
  } = useChatbot();
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleBookingSuccess = async () => {
    setShowTourBooking(false);
    const successMessage = "Thank you for booking a campus tour! We've received your booking request. Our admissions team will contact you within 24 hours to confirm your tour date and time. We look forward to showing you around our campus!";

    const { data } = await useChatbot();
    // Add success message to chat
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl h-[90vh] bg-white rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-4 flex items-center gap-3">
          <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center">
            <GraduationCap className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h1 className="text-xl font-bold">College Enquiry Assistant</h1>
            <p className="text-sm text-blue-100">Ask me anything about our college!</p>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-gray-50">
          {messages.map((message) => (
            <ChatMessage key={message.id} message={message} />
          ))}

          {isLoading && (
            <div className="flex gap-3 justify-start">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center">
                <Loader2 className="w-5 h-5 text-white animate-spin" />
              </div>
              <div className="bg-white rounded-2xl px-4 py-3 shadow-sm">
                <p className="text-sm text-gray-500">Typing...</p>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        <ChatInput onSend={sendMessage} disabled={isLoading} />
      </div>

      {showVirtualTour && (
        <VirtualTour onClose={() => setShowVirtualTour(false)} />
      )}

      {showTourBooking && (
        <TourBookingModal
          sessionId={sessionId}
          onClose={() => setShowTourBooking(false)}
          onSuccess={handleBookingSuccess}
        />
      )}
    </div>
  );
}
