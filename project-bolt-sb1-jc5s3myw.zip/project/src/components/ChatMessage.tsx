import { Bot, User } from 'lucide-react';
import { Message } from '../lib/supabase';

interface ChatMessageProps {
  message: Message;
}

export function ChatMessage({ message }: ChatMessageProps) {
  return (
    <div className={`flex gap-3 ${message.is_bot ? 'justify-start' : 'justify-end'}`}>
      {message.is_bot && (
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center">
          <Bot className="w-5 h-5 text-white" />
        </div>
      )}

      <div className={`max-w-[70%] rounded-2xl px-4 py-3 ${
        message.is_bot
          ? 'bg-white text-gray-800 shadow-sm'
          : 'bg-blue-600 text-white'
      }`}>
        <p className="text-sm leading-relaxed whitespace-pre-line">{message.content}</p>
        <span className="text-xs opacity-60 mt-1 block">
          {new Date(message.created_at).toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit'
          })}
        </span>
      </div>

      {!message.is_bot && (
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center">
          <User className="w-5 h-5 text-white" />
        </div>
      )}
    </div>
  );
}
