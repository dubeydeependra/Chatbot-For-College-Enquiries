import { useState, useEffect } from 'react';
import { supabase, Message, EnquiryTopic } from '../lib/supabase';

export function useChatbot() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [sessionId] = useState(() => `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`);
  const [enquiryTopics, setEnquiryTopics] = useState<EnquiryTopic[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showVirtualTour, setShowVirtualTour] = useState(false);
  const [showTourBooking, setShowTourBooking] = useState(false);

  useEffect(() => {
    loadEnquiryTopics();
    initializeConversation();
  }, []);

  const loadEnquiryTopics = async () => {
    const { data } = await supabase
      .from('enquiry_topics')
      .select('*');

    if (data) {
      setEnquiryTopics(data);
    }
  };

  const initializeConversation = async () => {
    const { data } = await supabase
      .from('conversations')
      .insert({ session_id: sessionId })
      .select()
      .single();

    if (data) {
      setConversationId(data.id);
      addWelcomeMessage(data.id);
    }
  };

  const addWelcomeMessage = async (convId: string) => {
    const welcomeText = "Hello! Welcome to our College Enquiry Chatbot. I'm here to help answer your questions about admissions, courses, fees, campus facilities, placements, and more. How can I assist you today?";

    const { data } = await supabase
      .from('messages')
      .insert({
        conversation_id: convId,
        content: welcomeText,
        is_bot: true
      })
      .select()
      .single();

    if (data) {
      setMessages([data]);
    }
  };

  const findBestResponse = (userMessage: string): { response: string; action?: string } => {
    const lowerMessage = userMessage.toLowerCase();

    const tourKeywords = ['virtual tour', 'campus tour', 'tour', 'visit', 'campus visit', 'show me campus'];
    if (tourKeywords.some(keyword => lowerMessage.includes(keyword))) {
      return {
        response: "I'd be happy to show you our beautiful campus virtually! Let me open the virtual tour for you. After viewing, you can also book an in-person campus visit.",
        action: 'showVirtualTour'
      };
    }

    const bookingKeywords = ['book tour', 'schedule tour', 'book visit', 'book campus visit', 'visit campus'];
    if (bookingKeywords.some(keyword => lowerMessage.includes(keyword))) {
      return {
        response: "Great! Let me help you book an in-person campus tour. I'll collect your details.",
        action: 'showTourBooking'
      };
    }

    for (const topic of enquiryTopics) {
      for (const keyword of topic.keywords) {
        if (lowerMessage.includes(keyword.toLowerCase())) {
          return { response: topic.response };
        }
      }
    }

    return {
      response: "I'm not sure I understand your question. I can help you with information about:\n\n• Admissions and application process\n• Available courses and programs\n• Fees and scholarships\n• Campus facilities\n• Placement records and career opportunities\n• Contact information\n• Virtual campus tour\n• Book a campus visit\n\nPlease ask me about any of these topics!"
    };
  };

  const sendMessage = async (content: string) => {
    if (!conversationId || !content.trim()) return;

    setIsLoading(true);

    const { data: userMessage } = await supabase
      .from('messages')
      .insert({
        conversation_id: conversationId,
        content,
        is_bot: false
      })
      .select()
      .single();

    if (userMessage) {
      setMessages(prev => [...prev, userMessage]);
    }

    const botResponseData = findBestResponse(content);

    setTimeout(async () => {
      const { data: botMessage } = await supabase
        .from('messages')
        .insert({
          conversation_id: conversationId,
          content: botResponseData.response,
          is_bot: true
        })
        .select()
        .single();

      if (botMessage) {
        setMessages(prev => [...prev, botMessage]);
      }

      if (botResponseData.action === 'showVirtualTour') {
        setShowVirtualTour(true);
      } else if (botResponseData.action === 'showTourBooking') {
        setShowTourBooking(true);
      }

      setIsLoading(false);
    }, 500);
  };

  return {
    messages,
    sendMessage,
    isLoading,
    showVirtualTour,
    setShowVirtualTour,
    showTourBooking,
    setShowTourBooking,
    sessionId
  };
}
