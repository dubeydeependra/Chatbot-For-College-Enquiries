/*
  # College Enquiry Chatbot Schema

  1. New Tables
    - `conversations`
      - `id` (uuid, primary key) - Unique conversation identifier
      - `session_id` (text) - Session identifier for grouping messages
      - `created_at` (timestamptz) - When conversation started
      
    - `messages`
      - `id` (uuid, primary key) - Unique message identifier
      - `conversation_id` (uuid, foreign key) - Links to conversations table
      - `content` (text) - Message content
      - `is_bot` (boolean) - Whether message is from bot or user
      - `created_at` (timestamptz) - When message was sent
      
    - `enquiry_topics`
      - `id` (uuid, primary key) - Unique topic identifier
      - `topic` (text) - Topic name (e.g., "admissions", "courses", "fees")
      - `keywords` (text[]) - Keywords to match for this topic
      - `response` (text) - Bot response for this topic
      - `created_at` (timestamptz) - When topic was created
      
  2. Security
    - Enable RLS on all tables
    - Allow public read access to enquiry_topics (for bot responses)
    - Allow public insert access to conversations and messages (for guest users)
    - Allow public read access to own conversation messages
    
  3. Notes
    - Session-based conversations for guest users
    - Predefined responses based on keywords
    - Full conversation history stored for analytics
*/

CREATE TABLE IF NOT EXISTS conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id text NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid REFERENCES conversations(id) ON DELETE CASCADE,
  content text NOT NULL,
  is_bot boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS enquiry_topics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  topic text NOT NULL,
  keywords text[] NOT NULL,
  response text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE enquiry_topics ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can create conversations"
  ON conversations FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can view conversations"
  ON conversations FOR SELECT
  USING (true);

CREATE POLICY "Anyone can create messages"
  ON messages FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can view messages"
  ON messages FOR SELECT
  USING (true);

CREATE POLICY "Anyone can view enquiry topics"
  ON enquiry_topics FOR SELECT
  USING (true);

INSERT INTO enquiry_topics (topic, keywords, response) VALUES
  ('admissions', ARRAY['admission', 'admissions', 'apply', 'application', 'join', 'enroll', 'enrollment'], 'Our college offers admissions for various undergraduate and postgraduate programs. The admission process typically starts in May. You can apply online through our website. Requirements include: 12th grade mark sheet, entrance exam scores (if applicable), and identity proof. Would you like to know about specific program requirements?'),
  ('courses', ARRAY['course', 'courses', 'program', 'programs', 'degree', 'degrees', 'study', 'branch'], 'We offer a wide range of courses including: Engineering (Computer Science, Mechanical, Electrical, Civil), Business Administration (BBA, MBA), Science (B.Sc, M.Sc), and Arts (BA, MA). Each program has specific eligibility criteria. Which field are you interested in?'),
  ('fees', ARRAY['fee', 'fees', 'cost', 'tuition', 'payment', 'scholarship', 'financial'], 'Our fee structure varies by program. Approximate annual fees: Engineering: $5,000-7,000, Business: $4,000-6,000, Science/Arts: $3,000-5,000. We also offer scholarships based on merit (up to 50% waiver) and need-based financial aid. Payment can be made in installments. Would you like detailed information about a specific program?'),
  ('campus', ARRAY['campus', 'facility', 'facilities', 'infrastructure', 'library', 'lab', 'hostel', 'accommodation'], 'Our campus spans 50 acres with modern facilities including: well-equipped laboratories, central library with 100,000+ books, computer centers, sports complex, auditorium, and separate hostels for boys and girls. We also have Wi-Fi throughout campus, cafeteria, medical center, and transport facilities. What specific facility would you like to know more about?'),
  ('placements', ARRAY['placement', 'placements', 'job', 'jobs', 'career', 'recruit', 'company', 'salary'], 'We have an excellent placement record with 85%+ students placed annually. Top recruiters include: Tech companies (Google, Microsoft, Amazon), Consulting firms (Deloitte, Accenture), and Banks. Average package ranges from $40,000-60,000 with highest package reaching $120,000. We also provide career counseling, training programs, and internship opportunities. Would you like placement statistics for a specific department?'),
  ('contact', ARRAY['contact', 'phone', 'email', 'address', 'location', 'reach', 'call'], 'You can reach us at: Phone: +1-234-567-8900, Email: admissions@college.edu, Address: 123 College Street, University City, State 12345. Office hours: Monday-Friday, 9 AM - 5 PM. You can also visit our website at www.college.edu or schedule a campus tour. How else can I assist you?'),
  ('greeting', ARRAY['hi', 'hello', 'hey', 'greetings', 'good morning', 'good afternoon', 'good evening'], 'Hello! Welcome to our College Enquiry Chatbot. I''m here to help answer your questions about admissions, courses, fees, campus facilities, placements, and more. How can I assist you today?'),
  ('thanks', ARRAY['thank', 'thanks', 'thank you', 'appreciate'], 'You''re welcome! If you have any more questions about our college, feel free to ask. Good luck with your educational journey!');
