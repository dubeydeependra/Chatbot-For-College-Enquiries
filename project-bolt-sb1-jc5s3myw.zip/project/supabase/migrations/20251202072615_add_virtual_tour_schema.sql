/*
  # Add Virtual Tour Feature

  1. New Tables
    - `tour_locations`
      - `id` (uuid, primary key) - Unique location identifier
      - `name` (text) - Location name (e.g., "Main Building", "Library")
      - `description` (text) - Location description
      - `image_url` (text) - Image URL for the location
      - `order` (integer) - Display order in tour
      - `created_at` (timestamptz) - When location was added
      
    - `tour_bookings`
      - `id` (uuid, primary key) - Unique booking identifier
      - `session_id` (text) - Session identifier from conversations
      - `preferred_date` (date) - Preferred tour date
      - `visitor_name` (text) - Visitor's name
      - `visitor_email` (text) - Visitor's email
      - `visitor_phone` (text) - Visitor's phone number
      - `status` (text) - Booking status (pending, confirmed, completed, cancelled)
      - `created_at` (timestamptz) - When booking was made
      
  2. Security
    - Enable RLS on all tables
    - Allow public read access to tour_locations
    - Allow public insert/read access to tour_bookings
    
  3. Notes
    - Pre-populated with campus locations
    - Virtual tour booking system for interested visitors
*/

CREATE TABLE IF NOT EXISTS tour_locations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text NOT NULL,
  image_url text NOT NULL,
  "order" integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS tour_bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id text NOT NULL,
  preferred_date date,
  visitor_name text NOT NULL,
  visitor_email text NOT NULL,
  visitor_phone text NOT NULL,
  status text DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE tour_locations ENABLE ROW LEVEL SECURITY;
ALTER TABLE tour_bookings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view tour locations"
  ON tour_locations FOR SELECT
  USING (true);

CREATE POLICY "Anyone can book tour"
  ON tour_bookings FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can view bookings"
  ON tour_bookings FOR SELECT
  USING (true);

INSERT INTO tour_locations (name, description, image_url, "order") VALUES
  ('Main Academic Building', 'The heart of our college featuring modern classrooms, lecture halls, and faculty offices. This state-of-the-art building showcases our commitment to academic excellence.', 'https://images.pexels.com/photos/3729463/pexels-photo-3729463.jpeg?auto=compress&cs=tinysrgb&w=600', 1),
  ('Central Library', 'Our expansive library with over 100,000 books, digital archives, reading rooms, and collaborative study spaces. Perfect for research and academic pursuits.', 'https://images.pexels.com/photos/3652355/pexels-photo-3652355.jpeg?auto=compress&cs=tinysrgb&w=600', 2),
  ('Computer Science Lab', 'Advanced computing facilities with the latest technology, workstations, and high-speed internet. Equipped for research and practical learning.', 'https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=600', 3),
  ('Engineering Labs', 'Comprehensive laboratories for all engineering disciplines featuring specialized equipment, testing facilities, and hands-on learning environments.', 'https://images.pexels.com/photos/3807517/pexels-photo-3807517.jpeg?auto=compress&cs=tinysrgb&w=600', 4),
  ('Sports Complex', 'World-class sports facilities including basketball courts, tennis grounds, swimming pool, gym, and indoor recreation areas.', 'https://images.pexels.com/photos/3583877/pexels-photo-3583877.jpeg?auto=compress&cs=tinysrgb&w=600', 5),
  ('Student Cafeteria', 'Modern dining facility serving nutritious and diverse meals. A comfortable space for students to relax and socialize between classes.', 'https://images.pexels.com/photos/3537985/pexels-photo-3537985.jpeg?auto=compress&cs=tinysrgb&w=600', 6),
  ('Boys Hostel', 'Comfortable residential accommodation with modern amenities including Wi-Fi, laundry facilities, recreational areas, and 24/7 security.', 'https://images.pexels.com/photos/3692857/pexels-photo-3692857.jpeg?auto=compress&cs=tinysrgb&w=600', 7),
  ('Girls Hostel', 'Secure and well-maintained residential facilities with all modern amenities, common rooms, and dedicated support staff.', 'https://images.pexels.com/photos/3692857/pexels-photo-3692857.jpeg?auto=compress&cs=tinysrgb&w=600', 8),
  ('Auditorium', 'Large capacity auditorium hosting seminars, workshops, conferences, and cultural events. Equipped with modern audio-visual systems.', 'https://images.pexels.com/photos/3634556/pexels-photo-3634556.jpeg?auto=compress&cs=tinysrgb&w=600', 9),
  ('Medical Center', 'On-campus medical facility providing healthcare services, emergency care, and health counseling for all students and staff.', 'https://images.pexels.com/photos/4021805/pexels-photo-4021805.jpeg?auto=compress&cs=tinysrgb&w=600', 10);
